package view;

import java.awt.BorderLayout;
import java.util.TimerTask;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Choice;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.SystemColor;

public class Tela_Jogo extends JFrame {
	public void Tela_Jogo(String nome) {
		
	}
	private JPanel Painel1;
	boolean proximo=true;
	public int i=0;
	boolean varnivel1=false;
	boolean varnivel2=false;
	boolean varnivel3=false;
	boolean varnivel4=false;
	boolean varnivel5=false;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
		
			public void run() {
				try {
					Tela_Jogo frame = new Tela_Jogo(" ");
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void Soundvencedor() {
		InputStream in;
		try {
		in=new FileInputStream(new File ("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\vitoria.wav"));
		AudioStream audios = new AudioStream(in);
		AudioPlayer.player.start(audios);
		
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	
	public Tela_Jogo(String nome,int pontuacao) {
		Primeira_tela primeiratela = new Primeira_tela();
		Tela_nivelamento telaniv = new Tela_nivelamento(nome);
	
		Nivel1 nivel1 = new Nivel1(nome);
		Nivel2 nivel2 = new Nivel2(nome);
		Nivel3 nivel3 = new Nivel3(nome);
		Nivel4 nivel4 = new Nivel4(nome);
		Nivel5 nivel5 = new Nivel5(nome);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 626, 434);
		Painel1 = new JPanel();
		Painel1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(Painel1);
		Painel1.setLayout(null);
		Painel1.setFocusable(true);
		Painel1.setBounds(100, 100, 626, 434);
		Button sair = new Button("Voltar ao Menu Principal");
		sair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Inicio inicio = new Inicio();
				inicio.setVisible(true);
				setVisible(false);
			}
		});
		sair.setBounds(10, 0, 169, 22);
		Painel1.add(sair);
		
		JTextPane txtpn1 = new JTextPane();
		txtpn1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		txtpn1.setEditable(false);
		
		
		JButton btnNewButton = new JButton("Nivelamento");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				telaniv.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setForeground(SystemColor.textHighlight);
		btnNewButton.setBounds(202, 184, 124, 22);
		btnNewButton.setVisible(true);
		btnNewButton.setEnabled(false);
		Painel1.add(btnNewButton);
		
		
		JButton btnReforo = new JButton("Refor\u00E7o");
		btnReforo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (pontuacao==15) {
					reforco reforco= new reforco(1,nome);
					reforco.setVisible(true);
					setVisible(false);
					
				}
				
				if (pontuacao==35) {
					reforco reforco= new reforco(2,nome);
					reforco.setVisible(true);
					setVisible(false);
				}
				
				if (pontuacao==55) {
					reforco reforco= new reforco(3,nome);
					reforco.setVisible(true);
					setVisible(false);
				}
				
				if (pontuacao==75) {
					reforco reforco= new reforco(4,nome);
					reforco.setVisible(true);
					setVisible(false);
					
				}
				
				if (pontuacao==95) {
					reforco reforco= new reforco(5,nome);
					reforco.setVisible(true);
					setVisible(false);
					
				}
				
				
			}
		});
		btnReforo.setEnabled(false);
		btnReforo.setForeground(SystemColor.textHighlight);
		btnReforo.setBounds(202, 205, 124, 22);
		btnReforo.setVisible(true);
		Painel1.add(btnReforo);
		
		
		
		JButton btnNivel_1 = new JButton("Nivel 1");
		btnNivel_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				nivel1.setVisible(true);
			}
		});
		btnNivel_1.setForeground(SystemColor.textHighlight);
		btnNivel_1.setEnabled(false);
		btnNivel_1.setVisible(true);
		btnNivel_1.setBounds(202, 227, 124, 22);
		Painel1.add(btnNivel_1);
		
		JButton btnNivel_2 = new JButton("Nivel 2\r\n");
		btnNivel_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				nivel2.setVisible(true);
			}
		});
		btnNivel_2.setForeground(SystemColor.textHighlight);
		btnNivel_2.setEnabled(false);
		btnNivel_2.setVisible(true);
		btnNivel_2.setBounds(202, 246, 124, 22);
		Painel1.add(btnNivel_2);
		
		JButton btnNivel_3 = new JButton("Nivel 3\r\n\r\n");
		btnNivel_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				nivel3.setVisible(true);
			}
		});
		btnNivel_3.setForeground(SystemColor.textHighlight);
		btnNivel_3.setEnabled(false);
		btnNivel_3.setBounds(202, 267, 124, 22);
		btnNivel_3.setVisible(true);
		Painel1.add(btnNivel_3);
		
		JButton btnNivel_4 = new JButton("Nivel 4\r\n\r\n");
		btnNivel_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				nivel4.setVisible(true);
			}
		});
		btnNivel_4.setForeground(SystemColor.textHighlight);
		btnNivel_4.setEnabled(false);
		btnNivel_4.setBounds(202, 286, 124, 22);
		btnNivel_4.setVisible(true);
		Painel1.add(btnNivel_4);
		
		JButton btnNivel_5 = new JButton("Nivel 5");
		btnNivel_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				nivel5.setVisible(true);
			}
		});
		btnNivel_5.setEnabled(false);
		btnNivel_5.setForeground(SystemColor.textHighlight);
		btnNivel_5.setBounds(202, 307, 124, 22);
		Painel1.add(btnNivel_5);
		btnNivel_5.setVisible(true);
		txtpn1.setBounds(398, 31, 124, 101);
		Painel1.add(txtpn1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2.jpg"));
		lblNewLabel.setBounds(0, 0, 620, 406);
		Painel1.add(lblNewLabel);
		
		
		if (pontuacao<=10){
			varnivel1=true;
			txtpn1.setText("Reparamos aqui e voc� far� o nivel 1, mas fique tranquilo, j� j� este escritorio estar� cheio de premios !"); 
			btnNivel_1.setEnabled(true);
			
			
		}
		
		if(pontuacao==15) {
			varnivel1=false;
			txtpn1.setText("Faremos um pequeno refor�o para fixar alguns conhecimentos. Em breve, voce estar� no nivel 2");
			btnReforo.setEnabled(true);
			btnNivel_1.setBackground(Color.RED);
	
			
		}
		
		if((pontuacao >=20 && pontuacao <35) || varnivel2==true) {
			varnivel2=true;
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel1.png"));
			txtpn1.setText("Parabens, j� conseguimos o primeiro item, o kit de primeiros socorros, avan�e para o nivel 2");
			btnNivel_1.setEnabled(true);
			btnNivel_2.setEnabled(true);
			
		}
		
		if(pontuacao==35) {
			varnivel2=false;
			btnNivel_2.setBackground(Color.RED);
			btnNivel_2.setEnabled(false);
			txtpn1.setText("Faremos um pequeno refor�o para fixar alguns conhecimentos.Em breve, voce estar� no nivel 3");
			btnNivel_1.setEnabled(true);
			btnReforo.setEnabled(true);
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel1.png"));
			
			
		}
		
		if((pontuacao>=40 && pontuacao<55)|| varnivel3==true) {
			varnivel3=true;
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel2.png"));
			txtpn1.setText("Parabens, al�m do primeiro socorros temos tamb�m o aparelho de pressao agora, avan�e para o nivel 3");
			btnNivel_1.setEnabled(true);
			btnNivel_2.setEnabled(true);
			btnNivel_3.setEnabled(true);
		}
		
		if (pontuacao==55) {
			varnivel3=false;
			btnNivel_3.setBackground(Color.RED);
			btnNivel_2.setEnabled(false);
			btnNivel_2.setEnabled(true);
			txtpn1.setText("Faremos um pequeno refor�o para fixar alguns conhecimentos.Em breve, voce estar� no nivel 4");
			btnNivel_1.setEnabled(true);
			btnReforo.setEnabled(true);
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel2.png"));
			
		}
		if((pontuacao>=60 && pontuacao < 75)|| varnivel4==true) {
			varnivel4=true;
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel3.png"));
			txtpn1.setText("Parabens, Temos 3 itens, primeiro socorros, aparelho de pressao e agora o microscopio oftalmologico, avan�e para o nivel 4");
			btnNivel_1.setEnabled(true);
			btnNivel_2.setEnabled(true);
			btnNivel_3.setEnabled(true);
			btnNivel_4.setEnabled(true);
			
			
			
		}
		
		if(pontuacao == 75 ) {
			varnivel4=false;
			btnNivel_4.setBackground(Color.RED);
			btnNivel_4.setEnabled(false);
			txtpn1.setText("Faremos um pequeno refor�o para fixar alguns conhecimentos.Em breve, voce estar� no nivel 5");
			btnNivel_1.setEnabled(true);
			btnNivel_2.setEnabled(true);
			btnNivel_3.setEnabled(true);
			btnReforo.setEnabled(true);
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel3.png"));
			
		}
		if((pontuacao>=80 && pontuacao < 95) || varnivel5==true) {
			varnivel5=true;
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel4.png"));
			txtpn1.setText("Parabens, Temos diversos itens. Entre eles, voce conseguiu uma cadeira de rodas e um monitor de eletrocardio, avan�e para o 5");
			btnNivel_1.setEnabled(true);
			btnNivel_2.setEnabled(true);
			btnNivel_3.setEnabled(true);
			btnNivel_4.setEnabled(true);
			btnNivel_5.setEnabled(true);
			
			
			
		}
		
		if (pontuacao == 95) {
			btnNivel_5.setBackground(Color.RED);
			btnNivel_5.setEnabled(false);
			txtpn1.setText("Faremos um pequeno refor�o para fixar alguns conhecimentos.Em breve, voce acabara o jogo e obtera todos os premios");
			btnNivel_1.setEnabled(true);
			btnNivel_2.setEnabled(true);
			btnNivel_3.setEnabled(true);
			btnNivel_4.setEnabled(true);
			btnReforo.setEnabled(true);
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2_nivel4.png"));
			
		}
		
		if (pontuacao == 100) {
			Soundvencedor();
			btnNivel_1.setVisible(false);
			btnNewButton.setVisible(false);
			btnReforo.setVisible(false);
			btnNivel_2.setVisible(false);
			btnNivel_3.setVisible(false);
			btnNivel_4.setVisible(false);
			btnNivel_5.setVisible(false);
			txtpn1.setText("PARABENS, voce obteve um diploma e j� tem otimos conhecimentos em medicina. OBRIGADO POR JOGAR Dr(a) "+nome.toUpperCase()+ "!");
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\parabens.jpg"));
			
		}
	}

	public Tela_Jogo(String nome) {
		Inicio inicio = new Inicio();
		String msg[]= new String[6];
		
		
		
		Primeira_tela primeiratela = new Primeira_tela();
		Tela_nivelamento telaniv = new Tela_nivelamento(nome);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 626, 434);
		Painel1 = new JPanel();
		Painel1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(Painel1);
		Painel1.setLayout(null);
		Painel1.setFocusable(true);
		Painel1.setBounds(100, 100, 626, 434);
		
		
		
		Button sair = new Button("Voltar ao Menu Principal");
		sair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Inicio inicio = new Inicio();
				inicio.setVisible(true);
				setVisible(false);
			}
		});
		sair.setBounds(10, 0, 169, 22);
		Painel1.add(sair);
		
		JTextPane txtpn1 = new JTextPane();
		txtpn1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtpn1.setEditable(false);
		msg[0]=" Ol�, voc� deve ser o(a) Doutor(Doutora): " +nome.toUpperCase()+", Que tal aprender medicina jogando?";
		msg[1]=" A Cada nivel concluido, voc� ir� receber um equipamento m�dico para seu escritorio.";
		msg[2]=" Lembrando que, o Jogo s� vai acabar quando o consultorio estiver completo";
		msg[3]="Ent�o VAMOS MONTAR O CONSULTORIO E APRENDER MEDICINA!!!";
		msg[4]="Para come�ar, Vamos realizar um nivelamento para sabermos se voce est� por dentro da area medica";
		msg[5]="� s� clicar no botao de nivelamento";
		
		JButton btnNewButton = new JButton("Nivelamento");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				telaniv.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setForeground(SystemColor.textHighlight);
		btnNewButton.setBounds(202, 184, 124, 22);
		btnNewButton.setVisible(false);
		Painel1.add(btnNewButton);
		
		JButton btnReforo = new JButton("Refor\u00E7o");
		btnReforo.setEnabled(false);
		btnReforo.setForeground(SystemColor.textHighlight);
		btnReforo.setBounds(202, 205, 124, 22);
		btnReforo.setVisible(false);
		Painel1.add(btnReforo);
		
		JButton btnNivel_1 = new JButton("Nivel 1");
		btnNivel_1.setForeground(SystemColor.textHighlight);
		btnNivel_1.setEnabled(false);
		btnNivel_1.setVisible(false);
		btnNivel_1.setBounds(202, 227, 124, 22);
		Painel1.add(btnNivel_1);
		
		JButton btnNivel_2 = new JButton("Nivel 2\r\n");
		btnNivel_2.setForeground(SystemColor.textHighlight);
		btnNivel_2.setEnabled(false);
		btnNivel_2.setVisible(false);
		btnNivel_2.setBounds(202, 246, 124, 22);
		Painel1.add(btnNivel_2);
		
		JButton btnNivel_3 = new JButton("Nivel 3\r\n\r\n");
		btnNivel_3.setForeground(SystemColor.textHighlight);
		btnNivel_3.setEnabled(false);
		btnNivel_3.setBounds(202, 267, 124, 22);
		btnNivel_3.setVisible(false);
		Painel1.add(btnNivel_3);
		
		JButton btnNivel_4 = new JButton("Nivel 4\r\n\r\n");
		btnNivel_4.setForeground(SystemColor.textHighlight);
		btnNivel_4.setEnabled(false);
		btnNivel_4.setBounds(202, 286, 124, 22);
		btnNivel_4.setVisible(false);
		Painel1.add(btnNivel_4);
		
		JButton btnNivel_5 = new JButton("Nivel 5");
		btnNivel_5.setEnabled(false);
		btnNivel_5.setForeground(SystemColor.textHighlight);
		btnNivel_5.setBounds(202, 307, 124, 22);
		Painel1.add(btnNivel_5);
		btnNivel_5.setVisible(false);
		txtpn1.setText(msg[0]);
		txtpn1.setBounds(398, 31, 124, 101);
		Painel1.add(txtpn1);
		
		JLabel lblAperteATecla = new JLabel("Aperte a Tecla Enter ou Seta direita para continuar");
		lblAperteATecla.setFont(new Font("Tahoma", Font.PLAIN, 21));
		Timer tempo = new Timer();
		tempo.schedule(new TimerTask() {
			
			public void run() {
				Painel1.addKeyListener(new KeyAdapter() {
					
					public void keyPressed(KeyEvent evt) {
						if ((evt.getKeyCode() == KeyEvent.VK_ENTER || evt.getKeyCode() == KeyEvent.VK_RIGHT)) {
								lblAperteATecla.setVisible(false);
							}
						else 
							lblAperteATecla.setVisible(true);
						}
							
					
				});
				lblAperteATecla.setVisible(true);
				
			}
		},4000);
		lblAperteATecla.setVisible(false);
		lblAperteATecla.setBounds(10, 372, 577, 34);
		Painel1.add(lblAperteATecla);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fundo2.jpg"));
		lblNewLabel.setBounds(0, 0, 620, 406);
		Painel1.add(lblNewLabel);
		
		Painel1.addKeyListener(new KeyAdapter() {
			
			public void keyPressed(KeyEvent evt) {
				if (evt.getKeyCode() == KeyEvent.VK_ENTER || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
						i=i+1;
						if (i == 5) {
							btnReforo.setVisible(true);
							btnNewButton.setVisible(true);
							btnNivel_1.setVisible(true);
							btnNivel_2.setVisible(true);
							btnNivel_3.setVisible(true);
							btnNivel_4.setVisible(true);
							btnNivel_5.setVisible(true);
						}
						txtpn1.setText(msg[i]);
						lblAperteATecla.setVisible(false);
					}
				}
					
			
		});

		
		
			
		}
	}


