package view;

import java.util.ArrayList;

public class Banco_de_perguntas_es {

	
	public ArrayList perguntanv1(int i) {
		String pergunta[] = new String[10];
		String Alt1[] = new String[10];
		String Alt2[] = new String[10];
		String Alt3[] = new String[10];
		String resposta[] = new String[10];
		String comentario[] = new String[10];
		String camimagem[] = new String[10];
		ArrayList<String> questao = new ArrayList();
		
		pergunta[0] = "Esta imagem se parece com qual org�o ?";
		Alt1[0]="Pancreas";
		Alt2[0]="Cora��o";
		Alt3[0]="Pulm�o";		
		resposta[0]="B";
		comentario[0]="A Imagem � um cora��o em 3D";
		camimagem[0]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\cora��o.png";
		
		pergunta[1] = "Com que orgao nesta imagem se parece? ";
		Alt1[1]="Intestino grosso";
		Alt2[1]="Ba�o";
		Alt3[1]="Pulm�o";
		resposta[1]="C";
		comentario[1]="O Org�o mostrado � um pulm�o";
		camimagem[1]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\pulmao.png";
		
		pergunta[2] = "Presente em todos os animais vertebrados, a figura ao lado mostra o:  ";
		Alt1[2]="Cerebro";
		Alt2[2]="Intestino delgado";
		Alt3[2]="Sistema digestivo";
		resposta[2]="A";
		comentario[2]="CEREBRO! � o principal �rg�o e centro do sistema nervoso em todos os animais vertebrados";
		camimagem[2]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\Cerebro.png";
		
		pergunta[3] = "O que � isto?";
		Alt1[3]="Pr�stata";
		Alt2[3]="Testiculo";
		Alt3[3]="Bexiga";
		resposta[3]="B";
		comentario[3]="A figura ao lado mostra um testiculo";
		camimagem[3]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\Testiculo.png";
		
		pergunta[4] = " Qual � este musculo ? ";
		Alt1[4]="Adutor";
		Alt2[4]="Biceps femoral";
		Alt3[4]="Quadriceps";
		resposta[4]="C";
		comentario[4]="Quadriceps, localizado na face anterior da coxa, envolvendo quase que por completo o f�mur";
		camimagem[4]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\quadrilatero.png";
		
		questao.add(pergunta[i]);
		questao.add(Alt1[i]);
		questao.add(Alt2[i]);
		questao.add(Alt3[i]);
		questao.add(resposta[i]);
		questao.add(comentario[i]);
		questao.add(camimagem[i]);
	return questao;
	
	}
	
	public ArrayList perguntanv2(int i) {
		String pergunta[] = new String[10];
		String Alt1[] = new String[10];
		String Alt2[] = new String[10];
		String Alt3[] = new String[10];
		String resposta[] = new String[10];
		String comentario[] = new String[10];
		String camimagem[] = new String[10];
		ArrayList<String> questao = new ArrayList();
		
		pergunta[0] = "Esta imagem se parece com qual org�o ?";
		Alt1[0]="Diafragma";
		Alt2[0]="Cora��o";
		Alt3[0]="Ba�o";		
		resposta[0]="C";
		comentario[0]="O ba�o � localizado no hipoc�ndrio esquerdo, cuja fun��o � destruir os gl�bulos vermelhos in�teis e liberar a hemoglobina";
		camimagem[0]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\ba�o.png";
		
		pergunta[1] = "Qual � o sistema dessa imagem ao lado? ";
		Alt1[1]="Sistema digestorio";
		Alt2[1]="Sistema respiratorio";
		Alt3[1]="Sistema cardiovascular";
		resposta[1]="B";
		comentario[1]="Conjunto de �rg�os respons�veis pelas trocas gasosas entre o organismo dos animais e o meio ambiente � o sistema respiratorio";
		camimagem[1]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\respiratorio.png";
		
		pergunta[2] = "E nesta?";
		Alt1[2]="Sistema digestorio";
		Alt2[2]="Sistema cardiovascular";
		Alt3[2]="Sistema respiratorio";
		resposta[2]="A";
		comentario[2]="O sistema digestorio respons�vel por obter dos alimentos ingeridos �s diferentes fun��es do organismo.";
		camimagem[2]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\digestivo.png";
		
		pergunta[3] = "Qual nome desse aparelho medico ";
		Alt1[3]="Aparelho de pressao";
		Alt2[3]="Estetoscopio";
		Alt3[3]="Estadiometro";
		resposta[3]="B";
		comentario[3]=" O estetosc�pio � um dispositivo m�dico ac�stico para ausculta ou para ouvir os sons internos de um animal ou corpo humano.";
		camimagem[3]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\Estetoscopio.png";
		
		pergunta[4] = " Qual � o nome dado a este exame na imagem? ";
		Alt1[4]="Ultrasom";
		Alt2[4]="Eletrograma";
		Alt3[4]="Radiografia";
		resposta[4]="C";
		comentario[4]="Radiografia um exame de imagem que utiliza raios X para ver um material cuja composi��o n�o � uniforme como o corpo humano";
		camimagem[4]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\raios-x.jpg";
		
		questao.add(pergunta[i]);
		questao.add(Alt1[i]);
		questao.add(Alt2[i]);
		questao.add(Alt3[i]);
		questao.add(resposta[i]);
		questao.add(comentario[i]);
		questao.add(camimagem[i]);
	return questao;
	
	}
	
	public ArrayList perguntanv3(int i) {
		String pergunta[] = new String[10];
		String Alt1[] = new String[10];
		String Alt2[] = new String[10];
		String Alt3[] = new String[10];
		String resposta[] = new String[10];
		String comentario[] = new String[10];
		String camimagem[] = new String[10];
		ArrayList<String> questao = new ArrayList();
		
		pergunta[0] = "O que � isto que se parece com uvas pequenas ?";
		Alt1[0]="Fornix vaginal";
		Alt2[0]="Cervix";
		Alt3[0]="Ov�rio";		
		resposta[0]="C";
		comentario[0]="Ov�rio sao as gl�ndulas do aparelho genital feminino, que libera os �vulos e secreta horm�nios.";
		camimagem[0]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\Ovario.png";
		
		pergunta[1] = "Agora sobre o cora��o, o que � isso em vermelho?";
		Alt1[1]="Aorta";
		Alt2[1]="Veia cava inferior";
		Alt3[1]="Art�ria pulmonar";
		resposta[1]="A";
		comentario[1]="Aorta � a maior e mais importante art�ria do sistema circulat�rio do corpo humano.";
		camimagem[1]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\Aorta.png";
		
		pergunta[2] = "Gl�ndula com formato semelhante ao de uma pequena borboleta. Estamos falando de quem ?";
		Alt1[2]="Tireoide";
		Alt2[2]="Meninge";
		Alt3[2]="Gladulas salivares";
		resposta[2]="A";
		comentario[2]="A tireoide age na fun��o de �rg�os importantes como o cora��o, c�rebro, f�gado e rins.";
		camimagem[2]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\tireoide.png";
		
		pergunta[3] = "� um canal muscular membranoso, que se comunica com o nariz e a boca, ligando-os � laringe e ao es�fago";
		Alt1[3]="Bronquios";
		Alt2[3]="Faringe";
		Alt3[3]="Traqueia";
		resposta[3]="B";
		comentario[3]=" A faringe � um tubo e tem a fun��o de fazer a passagem do ar inalado e dos alimentos ingeridos";
		camimagem[3]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\faringe.png";
		
		pergunta[4] = "Qual � o nome desse org�o ";
		Alt1[4]="Intestino Delgado";
		Alt2[4]="Intestino Grosso";
		Alt3[4]="Esofago";
		resposta[4]="B";
		comentario[4]="O intestino grosso � respons�vel pelo importante processo de absor��o da �gua para determinar o boco fecal.";
		camimagem[4]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\intestinogrosso.png";
		
		questao.add(pergunta[i]);
		questao.add(Alt1[i]);
		questao.add(Alt2[i]);
		questao.add(Alt3[i]);
		questao.add(resposta[i]);
		questao.add(comentario[i]);
		questao.add(camimagem[i]);
	return questao;
	
	}
	
	public ArrayList perguntanv4(int i) {
		String pergunta[] = new String[10];
		String Alt1[] = new String[10];
		String Alt2[] = new String[10];
		String Alt3[] = new String[10];
		String resposta[] = new String[10];
		String comentario[] = new String[10];
		String camimagem[] = new String[10];
		ArrayList<String> questao = new ArrayList();
		
		pergunta[0] = "Teste ergometrico, � indicado para avaliar a sa�de de um �rg�o, qual ?";
		Alt1[0]="Figado";
		Alt2[0]="Pulm�o";
		Alt3[0]="Cora��o";		
		resposta[0]="C";
		comentario[0]=" O teste submete o indiv�duo a uma determinada modalidade de esfor�o f�sico graduado e monitorado com eletrocardiograma";
		camimagem[0]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\ergometrico.jpg";
		
		pergunta[1] = "Pra que serve esse aparelho ?";
		Alt1[1]="Examinar as vistas";
		Alt2[1]="Para detectar doen�as no interior do ouvido" ;
		Alt3[1]="Verificar manchas na unha";
		resposta[1]="B";
		comentario[1]="Um otosc�pio � um equipamento m�dico utilizado para observar o interior da orelha.";
		camimagem[1]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\otoscopio.jpg";
		
		pergunta[2] = "Qual nome se d� a esse procedimento medico? ";
		Alt1[2]="Sutura";
		Alt2[2]="Anestesia";
		Alt3[2]="Ex�rese";
		resposta[2]="A";
		comentario[2]="Conhecida popularmente como pontos cir�rgicos, a Suruta, � um tipo de liga��o para manter unido alguns tecidos do corpo humano";
		camimagem[2]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\sutura.jpg";
		
		pergunta[3] = "Nesta imagem, um medico est� aplicando uma anestesia, como � chamada essa na imagem? ";
		Alt1[3]="Anestesia Vertebral";
		Alt2[3]="Anestesia Pedural";
		Alt3[3]="Anestesia Neuromuscular";
		resposta[3]="B";
		comentario[3]="Baseia-se na aplica��o de anest�sico em um espa�o virtual entre o ligamento amarelo e a dura-m�ter � a Anestesia pendural";
		camimagem[3]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\pedural.jpg";
		
		pergunta[4] = " A imagem mostra o sistema...";
		Alt1[4]="Sistema Endocrino";
		Alt2[4]="Sistema Linfatico";
		Alt3[4]="Sistema Nervoso";
		resposta[4]="B";
		comentario[4]="O Sistema linfatico � uma rede de vasos e pequenas estruturas  n�dulos linf�ticos que transportam o fluido linf�tico";
		camimagem[4]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\linfatico.jpg";
		
		questao.add(pergunta[i]);
		questao.add(Alt1[i]);
		questao.add(Alt2[i]);
		questao.add(Alt3[i]);
		questao.add(resposta[i]);
		questao.add(comentario[i]);
		questao.add(camimagem[i]);
	return questao;
	}
	
	
	public ArrayList perguntanv5(int i) {
		String pergunta[] = new String[10];
		String Alt1[] = new String[10];
		String Alt2[] = new String[10];
		String Alt3[] = new String[10];
		String resposta[] = new String[10];
		String comentario[] = new String[10];
		String camimagem[] = new String[10];
		ArrayList<String> questao = new ArrayList();
		
		pergunta[0] = "Qual nome se d� a esta sonda que � passada pelo nariz indo ate o estomago? ";
		Alt1[0]="Jejunostomia ";
		Alt2[0]="Nasograstica";
		Alt3[0]="Gastrotomia";		
		resposta[0]="B";
		comentario[0]="A Sonda Nasog�strica � um tubo, para alimenta��o por sonda, deve ser tecnicamente introduzido desde as narinas at� o est�mago";
		camimagem[0]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\nasogastrica.jpg";
		
		pergunta[1] = "Qual nome se da a esta tecnica que o medico/enfermeiro est� praticando na imagem ?";
		Alt1[1]="Desfibrila��o";
		Alt2[1]="Reanima��o cadiopulmonar" ;
		Alt3[1]="Compreens�o cardiaca";
		resposta[1]="A";
		comentario[1]="A desfibrila��o � a aplica��o de uma corrente el�trica com objetivo de restabelecer ou reorganizar o ritmo card�aco";
		camimagem[1]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\desfibrilacao.jpg";
		
		pergunta[2] = "Esse colete na imagem � muito utilizado para tratamento de diversas doen�as, EXCETO: ";
		Alt1[2]="Doen�as de schuermann";
		Alt2[2]="Hipercifoses";
		Alt3[2]="Osteoporose";
		resposta[2]="C";
		comentario[2]="O Colete de Milwaukee � usado em tratamentos de curvaturas colunais e n�o � indicado em primeiro momento para a Osteoporose.";
		camimagem[2]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\colete.jpg";
		
		pergunta[3] = "Qual nome desse osso que est� em vermelho na imagem? ";
		Alt1[3]="Tibia";
		Alt2[3]="Fibula";
		Alt3[3]="Patela";
		resposta[3]="B";
		comentario[3]="FIBULA, � um osso longo da perna no corpo humano, possui predomin�ncia na largura e na espessura";
		camimagem[3]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\fibula.png";
		
		pergunta[4] = "Como � chamado esse musculo do pesco�o pintado na imagem de vermelho ?";
		Alt1[4]="Esternocleidomast�ideo";
		Alt2[4]="Tiro-hioideu";
		Alt3[4]="Platisma";
		resposta[4]="C";
		comentario[4]="O platisma representa um m�sculo superficial, ocupando grande parte anterior do pesco�o.";
		camimagem[4]= "C:\\Users\\user\\eclipse-workspace\\InterfaceJogoIA\\src\\view\\platisma.jpg";
		
		questao.add(pergunta[i]);
		questao.add(Alt1[i]);
		questao.add(Alt2[i]);
		questao.add(Alt3[i]);
		questao.add(resposta[i]);
		questao.add(comentario[i]);
		questao.add(camimagem[i]);
	return questao;
	
	}
}
